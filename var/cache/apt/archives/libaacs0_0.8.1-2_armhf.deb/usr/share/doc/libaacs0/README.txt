Disclaimer
----------

This library is written for the purpose of playing Blu-ray movies. It is
intended for software that want to support Blu-ray playback (such as VLC and
MPlayer). We, the authors of this library, do not condone nor endorse piracy.

This library is simply a tool for playback of Blu-ray movies. Like any tool, the
use of this tool can also be abused. There are already numerous laws in
different countries and juridictions all over the world that protect copyrighted
material, such as Blu-ray movies. With that said, it would have been
inappropriate for us to distribute this library with terms such as "you cannot
use this library for piracy". Instead, we present to everyone this disclaimer.

As a reminder, here is also the disclaimer found at the beginning of any movie
in relation to copyrights.

ATTENTION

International agreement and national laws protect copyrighted motion pictures,
videotapes, and sound recordings.

UNAUTHORIZED REPRODUCTION, EXHIBITION OR DISTRIBUTION OF COPYRIGHTED MOTION
PICTURES CAN RESULT IN SEVERE CRIMINAL AND CIVIL PENALTIES UNDER THE LAWS OF
YOUR COUNTRY.

The International Criminal Police Organization - INTERPOL, has expressed its
concern about motion picture and sound recording piracy to all of its member
national police forces. (Resolution adopted at INTERPOL General Assembly,
Stockholm, Sweden, September 8, 1977.)
